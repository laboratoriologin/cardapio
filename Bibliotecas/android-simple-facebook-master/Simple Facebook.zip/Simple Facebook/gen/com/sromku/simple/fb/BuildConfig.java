/** Automatically generated file. DO NOT MODIFY */
package com.sromku.simple.fb;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}