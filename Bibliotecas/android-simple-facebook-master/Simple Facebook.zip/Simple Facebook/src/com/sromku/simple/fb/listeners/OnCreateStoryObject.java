package com.sromku.simple.fb.listeners;

public abstract class OnCreateStoryObject extends OnPublishListener {

}
