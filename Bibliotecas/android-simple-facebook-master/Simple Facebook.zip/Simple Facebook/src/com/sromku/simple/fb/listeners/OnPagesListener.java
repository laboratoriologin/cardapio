package com.sromku.simple.fb.listeners;

import java.util.List;

import com.sromku.simple.fb.entities.Page;

/**
 * On page request listener
 */
public abstract class OnPagesListener extends OnActionListener<List<Page>> {
}
