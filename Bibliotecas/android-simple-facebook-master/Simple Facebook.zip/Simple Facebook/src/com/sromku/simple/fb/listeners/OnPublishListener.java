package com.sromku.simple.fb.listeners;

/**
 * On publishing action listener
 * 
 * @author sromku
 */
public abstract class OnPublishListener extends OnActionListener<String> {
}
