package com.sromku.simple.fb.listeners;

public interface OnThinkingListetener extends OnErrorListener {

    void onThinking();
}
